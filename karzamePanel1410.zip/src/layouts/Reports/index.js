import React from 'react'

export default function Reports() {
  return (
    <div>Reports</div>
  )
}
