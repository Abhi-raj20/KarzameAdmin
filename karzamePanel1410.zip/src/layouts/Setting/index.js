import React from 'react'

export default function Setting() {
  return (
    <div>Setting</div>
  )
}
