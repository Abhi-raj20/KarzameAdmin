import React from 'react'

export default function ModeOfTransport() {
  return (
    <div>ModeOfTransport</div>
  )
}
