// socketService.js
import io from 'socket.io-client';

const socket = io('http://localhost:4000', {   // You can replace this URL with your API endpoint.
  transports: ['websocket', 'polling'],
  withCredentials: true,
});

// Export any methods needed for handling socket events
export const connectSocket = (onConnect, onDisconnect, onMessage) => {
  socket.on('connect', onConnect);
  socket.on('disconnect', onDisconnect);
  socket.on('message', onMessage);
};

export const disconnectSocket = () => {
  socket.off('connect');
  socket.off('disconnect');
  socket.off('message');
};

export const sendMessage = (message) => {
  socket.emit('message', message);
};

// export const userLiveLocation = (message) => {
//   socket.emit('message', message);
// };


export default socket;
